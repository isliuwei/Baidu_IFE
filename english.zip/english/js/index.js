var myApp = angular.module('myApp',['ngCookies','pascalprecht.translate']);


// var translations = {
//   HEADLINE: 'What an xx awesome module!',
//   PARAGRAPH: 'Srsly!',
//   NAMESPACE: {
//     PARAGRAPH: 'And it comes with awesome features!'
//   }
// };


// myApp.config(['$translateProvider', function ($translateProvider) {
//   // add translation table
//   $translateProvider
//     .translations('en', translations)
//     .preferredLanguage('en');
// }]);


// myApp.controller('myCtrl', ['$scope', '$translate', function ($scope, $translate) {
//   // expose translation via `$translate` service
//   $translate('HEADLINE').then(function (headline) {
//     $scope.headline = headline;
//   }, function (error) {
//     $scope.headline = error;
//   });
//   $translate('PARAGRAPH').then(function (paragraph) {
//     $scope.paragraph = paragraph;
//   }, function (error) {
//     $scope.paragraph = error;
//   });
//   $translate('NAMESPACE.PARAGRAPH').then(function (anotherOne) {
//     $scope.namespaced_paragraph = anotherOne;
//   }, function (error) {
//     $scope.namespaced_paragraph = error;
//   });
// }]);




var translationsEN = {
	NAV:{
		'item1':'Index',
		'item2':'About Us',
		'item3':'Course',
		'item4':'Team',
		'item5':'Recruit',
		'item6':'FAQ',
		'item7':'Contact',
		'item8':'News',
	},
	HEADLINE: 'Classic Text: Youth!',
  	AUTHOR: 'isliuwei',
  	CONTENT: 'Youth is not a time of life; it is a state of mind; it is not a matter of rosy cheeks, red lips and supple knees; it is a matter of the will, a quality of the imagination, a vigor of the emotions; it is the freshness of the deep springs of life. Youth means a temperamental predominance of courage over timidity, of the appetite for adventure over the love of ease. This often exists in a man of 60 more than a boy of 20. Nobody grows old merely by a number of years. We grow old by deserting our ideals. Years may wrinkle the skin, but to give up enthusiasm wrinkles the soul. Worry, fear, self-distrust bows the heart and turns the spirit back to dust. Whether 60 or 16, there is in every human being’s heart the lure of wonders, the unfailing appetite for what’s next and the joy of the game of living. In the center of your heart and my heart, there is a wireless station; so long as it receives messages of beauty, hope, courage and power from man and from the infinite, so long as you are young. When your aerials are down, and your spirit is covered with snows of cynicism and the ice of pessimism, then you’ve grown old, even at 20; but as long as your aerials are up, to catch waves of optimism, there’s hope you may die young at 80.',
	BUTTON_LANG_CHN: '中文',
    BUTTON_LANG_EN: 'ENGLISH',
    BG_COLOR: 'enStyle'
}

var translationsCHN = {
	NAV:{
		'item1':'首页',
		'item2':'关于我们',
		'item3':'课程体系',
		'item4':'麦金思团队',
		'item5':'招聘信息',
		'item6':'常见问题',
		'item7':'联系我们',
		'item8':'最新动态',
	},
	HEADLINE: '经典美文：青春！',
  	AUTHOR: '佚名',
  	CONTENT: '青春不是年华，而是心境；青春不是桃面、丹唇、柔膝，而是深沉的意志，恢宏的想象，炙热的恋情；青春是生命的深泉在涌流。 青春气贯长虹，勇锐盖过怯弱，进取压倒苟安。如此锐气，二十后生而有之，六旬男子则更多见。年岁有加，并非垂老，理想丢弃，方堕暮年。 岁月悠悠，衰微只及肌肤；热忱抛却，颓废必致灵魂。忧烦，惶恐，丧失自信，定使心灵扭曲，意气如灰。 无论年届花甲，拟或二八芳龄，心中皆有生命之欢乐，奇迹之诱惑，孩童般天真久盛不衰。人人心中皆有一台天线，只要你从天上人间接受美好、希望、欢乐、勇气和力量的信号，你就青春永驻，风华常存。一旦天线下降，锐气便被冰雪覆盖，玩世不恭、自暴自弃油然而生，即使年方二十，实已垂垂老矣；然则只要树起天线，捕捉乐观信号，你就有望在八十高龄告别尘寰时仍觉年轻。',
  	BUTTON_LANG_CHN: '中文',
 	BUTTON_LANG_EN: 'ENGLISH',
 	BG_COLOR: 'chnStyle'
 	

}


myApp.config(['$translateProvider', function ($translateProvider) {
  // add translation table
  $translateProvider.translations('chn', translationsCHN);
  $translateProvider.translations('en', translationsEN);
  $translateProvider.preferredLanguage('chn');
  $translateProvider.fallbackLanguage('chn');
  $translateProvider.useSanitizeValueStrategy('escape');
  //存储语言设置
  $translateProvider.useLocalStorage();
  
  //$translateProvider.useCookieStorage();

}]);


myApp.controller('myCtrl', ['$translate', '$scope', '$sce',function ($translate, $scope,$sce) {
 $scope.HTML = "<p class='bg-success'>hahah</p>";
 $scope.HTML = $sce.trustAsHtml($scope.HTML);
  $scope.changeLanguage = function (langKey) {
    $translate.use(langKey);
  };

}]);

